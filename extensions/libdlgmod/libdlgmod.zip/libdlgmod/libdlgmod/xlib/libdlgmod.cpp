/*

MIT License

Copyright © 2021-2026 Samuel Venable
Copyright © 2021 Nikita Krapivin
Copyright © 2021 Robert B. Colton

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/

#include <cstdio>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <clocale>

#include <mutex>
#include <string>
#include <thread>
#include <chrono>
#include <vector>
#include <sstream>
#include <algorithm>
#include <unordered_map>

#include <libdlgmod/libdlgmod.h>
#include <libdlgmod/general/lodepng.h>
#include <xprocess.hpp>
#if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
#include <nfd.h>
#endif

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>

#include <pthread.h>
#include <libgen.h>
#include <unistd.h>
#include <fcntl.h>

#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xutil.h>
#if !defined(LIBDLGMOD_SUPPRESS_DEPENDENCY_ERROR)
#include <X11/extensions/Xrandr.h>
#include <X11/extensions/Xinerama.h>
#endif

using std::string;
using std::stringstream;
using std::to_string;
using std::vector;

namespace dialog_module {

namespace {

#if !defined(LIBDLGMOD_SUPPRESS_DEPENDENCY_ERROR)
int displayX            = -1;
int displayY            = -1;

int displayWidth        = -1;
int displayHeight       = -1;

int displayXGetter      = -1;
int displayYGetter      = -1;

int displayWidthGetter  = -1;
int displayHeightGetter = -1;

void display_get_position(bool i, int *result) {
  Display *display = XOpenDisplay(NULL);
  *result = 0; Rotation original_rotation; 
  Window root = XDefaultRootWindow(display);
  XRRScreenConfiguration *conf = XRRGetScreenInfo(display, root);
  SizeID original_size_id = XRRConfigCurrentConfiguration(conf, &original_rotation);
  if (XineramaIsActive(display)) {
    int m = 0; XineramaScreenInfo *xrrp = XineramaQueryScreens(display, &m);
    if (!i) *result = xrrp[original_size_id].x_org;
    else if (i) *result = xrrp[original_size_id].y_org;
    XFree(xrrp);
  }
  XCloseDisplay(display);
}

void display_get_size(bool i, int *result) {
  Display *display = XOpenDisplay(NULL);
  *result = 0; int num_sizes; Rotation original_rotation; 
  Window root = XDefaultRootWindow(display);
  int screen = XDefaultScreen(display);
  XRRScreenConfiguration *conf = XRRGetScreenInfo(display, root);
  SizeID original_size_id = XRRConfigCurrentConfiguration(conf, &original_rotation);
  if (XineramaIsActive(display)) {
    XRRScreenSize *xrrs = XRRSizes(display, screen, &num_sizes);
    if (!i) *result = xrrs[original_size_id].width;
    else if (i) *result = xrrs[original_size_id].height;
  } else if (!i) *result = XDisplayWidth(display, screen);
  else if (i) *result = XDisplayHeight(display, screen);
  XCloseDisplay(display);
}

int display_get_x() {
  if (displayXGetter == displayX && displayX != -1)
    return displayXGetter;
  display_get_position(false, &displayXGetter);
  int result = displayXGetter;
  displayX = result;
  return result;
}

int display_get_y() { 
  if (displayYGetter == displayY && displayY != -1)
    return displayYGetter;
  display_get_position(true, &displayYGetter);
  int result = displayYGetter;
  displayY = result;
  return result;
}

int display_get_width() {
  if (displayWidthGetter == displayWidth && displayWidth != -1) 
    return displayWidthGetter;
  display_get_size(false, &displayWidthGetter);
  int result = displayWidthGetter;
  displayWidth = result;
  return result;
}

int display_get_height() {
  if (displayHeightGetter == displayHeight && displayHeight != -1)
    return displayHeightGetter;
  display_get_size(true, &displayHeightGetter);
  int result = displayHeightGetter;
  displayHeight = result;
  return result;
}
#endif

int const dm_x11     = -1;
int const dm_zenity  =  0;
int const dm_kdialog =  1;
int dm_dialogengine  = -1;

void *owner = nullptr;
string caption;
string current_icon;
bool modifyInit = false;
bool cancel_pressed = false;

enum BUTTON_TYPES {
  BUTTON_ABORT,
  BUTTON_IGNORE,
  BUTTON_OK,
  BUTTON_CANCEL,
  BUTTON_YES,
  BUTTON_NO,
  BUTTON_RETRY
};

enum CAPTION_TYPES {
  CAPTION_INFORMATION,
  CAPTION_QUESTION,
  CAPTION_INPUT,
  CAPTION_OPEN,
  CAPTION_SAVE,
  CAPTION_DIRECTORY,
  CAPTION_COLOR,
  CAPTION_ERROR
};

int const btn_array_len = 7;
string btn_array[btn_array_len] = { "Abort", "Ignore", "OK", "Cancel", "Yes", "No", "Retry" };

int const cpt_array_len = 8;
string cpt_array[cpt_array_len] = { "Information", "Question", "Input Query", "Open", "Save As", "Select Directory", "Color", "Error" };

void widget_set_locale_helper() {
  const char *ptr = std::setlocale(LC_ALL, "");  
  if (ptr && strlen(ptr) >= 2) {
    if (ptr[0] == 'e' && ptr[1] == 'n') {
      // en = English

      btn_array[BUTTON_ABORT] = "Abort";
      btn_array[BUTTON_IGNORE] = "Ignore";
      btn_array[BUTTON_OK] = "OK";
      btn_array[BUTTON_CANCEL] = "Cancel";
      btn_array[BUTTON_YES] = "Yes";
      btn_array[BUTTON_NO] = "No";
      btn_array[BUTTON_RETRY] = "Retry";

      cpt_array[CAPTION_INFORMATION] = "Information";
      cpt_array[CAPTION_QUESTION] = "Question";
      cpt_array[CAPTION_INPUT] = "Input Query";
      cpt_array[CAPTION_OPEN] = "Open";
      cpt_array[CAPTION_SAVE] = "Save As";
      cpt_array[CAPTION_DIRECTORY] = "Select Directory";
      cpt_array[CAPTION_COLOR] = "Color";
      cpt_array[CAPTION_ERROR] = "Error";

    } else if (ptr[0] == 'f' && ptr[1] == 'r') {
      // fr = French

      btn_array[BUTTON_ABORT] = "Avorter";
      btn_array[BUTTON_IGNORE] = "Ignorer";
      btn_array[BUTTON_OK] = "D'ACCORD";
      btn_array[BUTTON_CANCEL] = "Annuler";
      btn_array[BUTTON_YES] = "Oui";
      btn_array[BUTTON_NO] = "Non";
      btn_array[BUTTON_RETRY] = "Réessayer";

      cpt_array[CAPTION_INFORMATION] = "Information";
      cpt_array[CAPTION_QUESTION] = "Question";
      cpt_array[CAPTION_INPUT] = "Requête d'entrée";
      cpt_array[CAPTION_OPEN] = "Ouvrir";
      cpt_array[CAPTION_SAVE] = "Enregistrer sous";
      cpt_array[CAPTION_DIRECTORY] = "Sélectionner un répertoire";
      cpt_array[CAPTION_COLOR] = "Couleur";
      cpt_array[CAPTION_ERROR] = "Erreur";

    } else if (ptr[0] == 'd' && ptr[1] == 'e') {
      // de = German

      btn_array[BUTTON_ABORT] = "Abbrechen";
      btn_array[BUTTON_IGNORE] = "Ignorieren";
      btn_array[BUTTON_OK] = "OK";
      btn_array[BUTTON_CANCEL] = "Stornieren";
      btn_array[BUTTON_YES] = "Ja";
      btn_array[BUTTON_NO] = "NEIN";
      btn_array[BUTTON_RETRY] = "Wiederholen";

      cpt_array[CAPTION_INFORMATION] = "Information";
      cpt_array[CAPTION_QUESTION] = "Frage";
      cpt_array[CAPTION_INPUT] = "Eingabeabfrage";
      cpt_array[CAPTION_OPEN] = "Offen";
      cpt_array[CAPTION_SAVE] = "Speichern unter";
      cpt_array[CAPTION_DIRECTORY] = "Verzeichnis auswählen";
      cpt_array[CAPTION_COLOR] = "Farbe";
      cpt_array[CAPTION_ERROR] = "Fehler";

    } else if (ptr[0] == 'e' && ptr[1] == 's') {
      // es = Spanish

      btn_array[BUTTON_ABORT] = "Abortar";
      btn_array[BUTTON_IGNORE] = "Ignorar";
      btn_array[BUTTON_OK] = "DE ACUERDO";
      btn_array[BUTTON_CANCEL] = "Cancelar";
      btn_array[BUTTON_YES] = "Sí";
      btn_array[BUTTON_NO] = "No";
      btn_array[BUTTON_RETRY] = "Rever";

      cpt_array[CAPTION_INFORMATION] = "Información";
      cpt_array[CAPTION_QUESTION] = "Pregunta";
      cpt_array[CAPTION_INPUT] = "Consulta de entrada";
      cpt_array[CAPTION_OPEN] = "Abierta";
      cpt_array[CAPTION_SAVE] = "Guardar como";
      cpt_array[CAPTION_DIRECTORY] = "Seleccionar directorio";
      cpt_array[CAPTION_COLOR] = "Color";
      cpt_array[CAPTION_ERROR] = "Error";

    } else if (ptr[0] == 'z' && ptr[1] == 'h') {
      // zh = Chinese
  
      btn_array[BUTTON_ABORT] = "中止";
      btn_array[BUTTON_IGNORE] = "忽略";
      btn_array[BUTTON_OK] = "好的";
      btn_array[BUTTON_CANCEL] = "取消";
      btn_array[BUTTON_YES] = "是的";
      btn_array[BUTTON_NO] = "不";
      btn_array[BUTTON_RETRY] = "重试";

      cpt_array[CAPTION_INFORMATION] = "信息";
      cpt_array[CAPTION_QUESTION] = "问题";
      cpt_array[CAPTION_INPUT] = "输入查询";
      cpt_array[CAPTION_OPEN] = "打开";
      cpt_array[CAPTION_SAVE] = "另存为";
      cpt_array[CAPTION_DIRECTORY] = "选择目录";
      cpt_array[CAPTION_COLOR] = "颜色";
      cpt_array[CAPTION_ERROR] = "错误";

    } else if (ptr[0] == 'j' && ptr[1] == 'a') {
      // ja = Japanese
  
      btn_array[BUTTON_ABORT] = "アボート";
      btn_array[BUTTON_IGNORE] = "無視する";
      btn_array[BUTTON_OK] = "わかりました";
      btn_array[BUTTON_CANCEL] = "キャンセル";
      btn_array[BUTTON_YES] = "はい";
      btn_array[BUTTON_NO] = "いいえ";
      btn_array[BUTTON_RETRY] = "リトライ";

      cpt_array[CAPTION_INFORMATION] = "情報";
      cpt_array[CAPTION_QUESTION] = "質問";
      cpt_array[CAPTION_INPUT] = "入力クエリ";
      cpt_array[CAPTION_OPEN] = "開ける";
      cpt_array[CAPTION_SAVE] = "名前を付けて保存";
      cpt_array[CAPTION_DIRECTORY] = "ディレクトリを選択";
      cpt_array[CAPTION_COLOR] = "色";
      cpt_array[CAPTION_ERROR] = "エラー";

    } else if (ptr[0] == 'k' && ptr[1] == 'o') {
      // ko = Korean

      btn_array[BUTTON_ABORT] = "중단";
      btn_array[BUTTON_IGNORE] = "무시하다";
      btn_array[BUTTON_OK] = "좋아요";
      btn_array[BUTTON_CANCEL] = "취소";
      btn_array[BUTTON_YES] = "예";
      btn_array[BUTTON_NO] = "아니요";
      btn_array[BUTTON_RETRY] = "다시 해 보다";

      cpt_array[CAPTION_INFORMATION] = "정보";
      cpt_array[CAPTION_QUESTION] = "질문";
      cpt_array[CAPTION_INPUT] = "입력 쿼리";
      cpt_array[CAPTION_OPEN] = "열려 있는";
      cpt_array[CAPTION_SAVE] = "다른 이름으로 저장";
      cpt_array[CAPTION_DIRECTORY] = "디렉터리 선택";
      cpt_array[CAPTION_COLOR] = "색상";
      cpt_array[CAPTION_ERROR] = "오류";

    } else if (ptr[0] == 'r' && ptr[1] == 'u') {
      // ru = Russian

      btn_array[BUTTON_ABORT] = "Отмена";
      btn_array[BUTTON_IGNORE] = "Игнорировать";
      btn_array[BUTTON_OK] = "ХОРОШО";
      btn_array[BUTTON_CANCEL] = "Отмена";
      btn_array[BUTTON_YES] = "Да";
      btn_array[BUTTON_NO] = "Нет";
      btn_array[BUTTON_RETRY] = "Повторить попытку";

      cpt_array[CAPTION_INFORMATION] = "Информация";
      cpt_array[CAPTION_QUESTION] = "Вопрос";
      cpt_array[CAPTION_INPUT] = "Входной запрос";
      cpt_array[CAPTION_OPEN] = "Открыть";
      cpt_array[CAPTION_SAVE] = "Сохранить как";
      cpt_array[CAPTION_DIRECTORY] = "Выберите каталог";
      cpt_array[CAPTION_COLOR] = "Цвет";
      cpt_array[CAPTION_ERROR] = "Ошибка";

    } else if (ptr[0] == 'p' && ptr[1] == 't') {
      // pt = Portuguese

      btn_array[BUTTON_ABORT] = "Abortar";
      btn_array[BUTTON_IGNORE] = "Ignorar";
      btn_array[BUTTON_OK] = "OK";
      btn_array[BUTTON_CANCEL] = "Cancelar";
      btn_array[BUTTON_YES] = "Sim";
      btn_array[BUTTON_NO] = "Não";
      btn_array[BUTTON_RETRY] = "Tentar novamente";

      cpt_array[CAPTION_INFORMATION] = "Informação";
      cpt_array[CAPTION_QUESTION] = "Pergunta";
      cpt_array[CAPTION_INPUT] = "Consulta de entrada";
      cpt_array[CAPTION_OPEN] = "Abrir";
      cpt_array[CAPTION_SAVE] = "Salvar como";
      cpt_array[CAPTION_DIRECTORY] = "Selecionar diretório";
      cpt_array[CAPTION_COLOR] = "Cor";
      cpt_array[CAPTION_ERROR] = "Erro";

    } else if (ptr[0] == 'a' && ptr[1] == 'r') {
      // ar = Arabic

      btn_array[BUTTON_ABORT] = "إلغاء";
      btn_array[BUTTON_IGNORE] = "يتجاهل";
      btn_array[BUTTON_OK] = "نعم";
      btn_array[BUTTON_CANCEL] = "يلغي";
      btn_array[BUTTON_YES] = "نعم";
      btn_array[BUTTON_NO] = "لا";
      btn_array[BUTTON_RETRY] = "إعادة المحاولة";

      cpt_array[CAPTION_INFORMATION] = "معلومة";
      cpt_array[CAPTION_QUESTION] = "سؤال";
      cpt_array[CAPTION_INPUT] = "استعلام الإدخال";
      cpt_array[CAPTION_OPEN] = "يفتح";
      cpt_array[CAPTION_SAVE] = "حفظ باسم";
      cpt_array[CAPTION_DIRECTORY] = "اختر المجلد";
      cpt_array[CAPTION_COLOR] = "لون";
      cpt_array[CAPTION_ERROR] = "خطأ";

    } else if (ptr[0] == 'h' && ptr[1] == 'i') {
      // hi = Hindi

      btn_array[BUTTON_ABORT] = "बीच में बंद करें";
      btn_array[BUTTON_IGNORE] = "अनदेखा करना";
      btn_array[BUTTON_OK] = "ठीक है";
      btn_array[BUTTON_CANCEL] = "रद्द करना";
      btn_array[BUTTON_YES] = "हाँ";
      btn_array[BUTTON_NO] = "नहीं";
      btn_array[BUTTON_RETRY] = "पुन: प्रयास करें";

      cpt_array[CAPTION_INFORMATION] = "जानकारी";
      cpt_array[CAPTION_QUESTION] = "सवाल";
      cpt_array[CAPTION_INPUT] = "इनपुट क्वेरी";
      cpt_array[CAPTION_OPEN] = "खुला";
      cpt_array[CAPTION_SAVE] = "के रूप रक्षित करें";
      cpt_array[CAPTION_DIRECTORY] = "डायरेक्टरी चुनें";
      cpt_array[CAPTION_COLOR] = "रंग";
      cpt_array[CAPTION_ERROR] = "गलती";

    } else if (ptr[0] == 'i' && ptr[1] == 't') {
      // it = Italian

      btn_array[BUTTON_ABORT] = "Interrompi";
      btn_array[BUTTON_IGNORE] = "Ignorare";
      btn_array[BUTTON_OK] = "OK";
      btn_array[BUTTON_CANCEL] = "Cancellare";
      btn_array[BUTTON_YES] = "SÌ";
      btn_array[BUTTON_NO] = "NO";
      btn_array[BUTTON_RETRY] = "Riprova";

      cpt_array[CAPTION_INFORMATION] = "Informazioni";
      cpt_array[CAPTION_QUESTION] = "Domanda";
      cpt_array[CAPTION_INPUT] = "Query di input";
      cpt_array[CAPTION_OPEN] = "Aprire";
      cpt_array[CAPTION_SAVE] = "Salva con nome";
      cpt_array[CAPTION_DIRECTORY] = "Seleziona directory";
      cpt_array[CAPTION_COLOR] = "Colore";
      cpt_array[CAPTION_ERROR] = "Errore";

    } else if (ptr[0] == 'n' && ptr[1] == 'l') {
      // nl = Dutch

      btn_array[BUTTON_ABORT] = "Afbreken";
      btn_array[BUTTON_IGNORE] = "Negeren";
      btn_array[BUTTON_OK] = "OK";
      btn_array[BUTTON_CANCEL] = "Annuleren";
      btn_array[BUTTON_YES] = "Ja";
      btn_array[BUTTON_NO] = "Nee";
      btn_array[BUTTON_RETRY] = "Opnieuw proberen";

      cpt_array[CAPTION_INFORMATION] = "Informatie";
      cpt_array[CAPTION_QUESTION] = "Vraag";
      cpt_array[CAPTION_INPUT] = "Invoervraag";
      cpt_array[CAPTION_OPEN] = "Open";
      cpt_array[CAPTION_SAVE] = "Opslaan als";
      cpt_array[CAPTION_DIRECTORY] = "Map selecteren";
      cpt_array[CAPTION_COLOR] = "Kleur";
      cpt_array[CAPTION_ERROR] = "Fout";

    }
  }
}

bool message_cancel  = false;
bool question_cancel = false;

bool dialog_position = false;
bool dialog_size     = false;
 
int      dialog_xpos   = 0;
int      dialog_ypos   = 0;
unsigned dialog_width  = 0;
unsigned dialog_height = 0;

unsigned nlpo2dc(unsigned x) {
  x--;
  x |= x >> 1;
  x |= x >> 2;
  x |= x >> 4;
  x |= x >> 8;
  return x | (x >> 16);
}

void XSetIcon(Display *display, Window window, const char *icon) {
  XSynchronize(display, true);
  Atom property = XInternAtom(display, "_NET_WM_ICON", true);

  unsigned char *data = nullptr;
  unsigned pngwidth, pngheight;
  unsigned error = lodepng_decode32_file(&data, &pngwidth, &pngheight, icon);
  if (error) return;

  unsigned
    widfull = nlpo2dc(pngwidth) + 1,
    hgtfull = nlpo2dc(pngheight) + 1,
    ih, iw;

  const int bitmap_size = widfull * hgtfull * 4;
  unsigned char *bitmap = new unsigned char[bitmap_size]();

  unsigned i = 0;
  unsigned elem_numb = 2 + pngwidth * pngheight;
  unsigned long *result = new unsigned long[elem_numb]();

  result[i++] = pngwidth;
  result[i++] = pngheight;
  for (ih = 0; ih < pngheight; ih++) {
    unsigned tmp = ih * widfull * 4;
    for (iw = 0; iw < pngwidth; iw++) {
      bitmap[tmp + 0] = data[4 * pngwidth * ih + iw * 4 + 2];
      bitmap[tmp + 1] = data[4 * pngwidth * ih + iw * 4 + 1];
      bitmap[tmp + 2] = data[4 * pngwidth * ih + iw * 4 + 0];
      bitmap[tmp + 3] = data[4 * pngwidth * ih + iw * 4 + 3];
      result[i++] = bitmap[tmp + 0] | (bitmap[tmp + 1] << 8) | (bitmap[tmp + 2] << 16) | (bitmap[tmp + 3] << 24);
      tmp += 4;
    }
  }

  XChangeProperty(display, window, property, XA_CARDINAL, 32, PropModeReplace, (unsigned char *)result, elem_numb);
  XFlush(display);
  delete[] result;
  delete[] bitmap;
  delete[] data;
}

string string_replace_all(string str, string substr, string nstr) {
  size_t pos = 0;
  while ((pos = str.find(substr, pos)) != string::npos) {
    str.replace(pos, substr.length(), nstr);
    pos += nstr.length();
  }
  return str;
}

vector<string> string_split(string str, char delimiter) {
  vector<string> vec;
  stringstream sstr(str);
  string tmp;
  while (std::getline(sstr, tmp, delimiter))
    vec.push_back(tmp);
  return vec;
}

bool file_exists(string fname) {
  struct stat sb;
  return (stat(fname.c_str(), &sb) == 0 &&
    S_ISREG(sb.st_mode) != 0);
}

string filename_absolute(string fname) {
  char result[PATH_MAX];
  if (realpath(fname.c_str(), result)) {
    if (file_exists(result)) {
      return result;
    }
  }
  return "";
}

string filename_name(string fname) {
  size_t fp = fname.find_last_of("/");
  return fname.substr(fp + 1);
}

string filename_ext(string fname) {
  fname = filename_name(fname);
  size_t fp = fname.find_last_of(".");
  if (fp == string::npos)
    return "";
  return fname.substr(fp);
}

int XErrorHandlerImpl(Display *display, XErrorEvent *event) {
  return 0;
}

int XIOErrorHandlerImpl(Display *display) {
  return 0;
}

void SetErrorHandlers() {
  XSetErrorHandler(XErrorHandlerImpl);
  XSetIOErrorHandler(XIOErrorHandlerImpl);
}

void XSetIcon(Display *display, Window window, const char *icon);

void change_relative_to_qt() {
  cancel_pressed = false;
  if (dm_dialogengine == dm_x11) {
    bool in_path = false, is_qt = false;
    const char *path = getenv("PATH");
    if (path && path[0] != '\0') {
      const char *ptr = getenv("XDG_CURRENT_DESKTOP");
      string str = ((ptr) ? ptr : "");
      if (!str.empty()) {
        std::transform(str.begin(), str.end(), str.begin(), ::toupper);
        is_qt = (str.find("KDE") != string::npos || str.find("TDE") != string::npos || 
          str.find("LXQT") != string::npos || str.find("RAZOR") != string::npos || 
          str.find("CUTEFISH") != string::npos || str.find("DEEPIN") != string::npos || 
          str.find("DDE") != string::npos || str.find("UKUI") != string::npos || 
          str.find("LUMINA") != string::npos || str.find("QT") != string::npos);
      }
      if (is_qt) {
        struct stat st;
        string buf;
        string cmd = "kdialog";
        string cpp_path(path);
        stringstream ss(cpp_path);
        char resolved_path[PATH_MAX];
        while (std::getline(ss, buf, ':')) {
          if (realpath((buf + string("/") + cmd).c_str(), resolved_path) && 
            !stat(resolved_path, &st) && S_ISREG(st.st_mode) && (st.st_mode & S_IXUSR)) {
            setenv("QT_QPA_PLATFORM", "xcb", 1);
            dm_dialogengine = dm_kdialog;
            in_path = true;
            break;
          }
        }
        if (!in_path) {
          struct stat st;
          string buf;
          string cmd = "zenity";
          string cpp_path(path);
          stringstream ss(cpp_path);
          char resolved_path[PATH_MAX];
          while (std::getline(ss, buf, ':')) {
            if (realpath((buf + string("/") + cmd).c_str(), resolved_path) && 
              !stat(resolved_path, &st) && S_ISREG(st.st_mode) && (st.st_mode & S_IXUSR)) {
              setenv("GDK_BACKEND", "x11", 1);
              dm_dialogengine = dm_zenity;
              in_path = true;
              break;
            }
          }
        }
      } else {
        struct stat st;
        string buf;
        string cmd = "zenity";
        string cpp_path(path);
        stringstream ss(cpp_path);
        char resolved_path[PATH_MAX];
        while (std::getline(ss, buf, ':')) {
          if (realpath((buf + string("/") + cmd).c_str(), resolved_path) && 
            !stat(resolved_path, &st) && S_ISREG(st.st_mode) && (st.st_mode & S_IXUSR)) {
            setenv("GDK_BACKEND", "x11", 1);
            dm_dialogengine = dm_zenity;
            in_path = true;
            break;
          }
        }
        if (!in_path) {
          struct stat st;
          string buf;
          string cmd = "kdialog";
          string cpp_path(path);
          stringstream ss(cpp_path);
          char resolved_path[PATH_MAX];
          while (std::getline(ss, buf, ':')) {
            if (realpath((buf + string("/") + cmd).c_str(), resolved_path) && 
              !stat(resolved_path, &st) && S_ISREG(st.st_mode) && (st.st_mode & S_IXUSR)) {
              setenv("QT_QPA_PLATFORM", "xcb", 1);
              dm_dialogengine = dm_kdialog;
              in_path = true;
              break;
            }
          }
        }
      }
    }
    #if !defined(LIBDLGMOD_SUPPRESS_DEPENDENCY_ERROR)
    if (!in_path) {
      SetErrorHandlers();
      Display *display = XOpenDisplay(nullptr);
      if (display) {
        int screen = DefaultScreen(display);
        Window owner = (Window)(std::intptr_t)strtoul(widget_get_owner(), nullptr, 10);
        Window parent = ((owner) ? owner : RootWindow(display, screen));
        int xpos = display_get_x() + ((display_get_width() - 550) / 2);
        int ypos = display_get_y() + ((display_get_height() - (32 * 4)) / 2);
        Window window = XCreateSimpleWindow(display, parent, 
        0, 0, 550, 32 * 4, 1, BlackPixel(display, screen), WhitePixel(display, screen));
        XStoreName(display, window, "Fatal Error");
        if (owner && owner != RootWindow(display, screen)) {
          XStoreName(display, owner, "Fatal Error");
          XSetIcon(display, owner, widget_get_icon());
          XResizeWindow(display, owner, 550, 32 * 4);
          XSizeHints *size_hints = XAllocSizeHints();
          size_hints->flags &= ~PPosition;
          size_hints->flags |= USPosition;
          size_hints->x = xpos;
          size_hints->y = ypos;
          XSetWMNormalHints(display, owner, size_hints);
          XMoveWindow(display, owner, xpos, ypos);
          XFree(size_hints);
        }
        XSelectInput(display, window, ExposureMask | KeyPressMask);
        XMapWindow(display, window);
        XSetIcon(display, window, widget_get_icon());
        const char *err1 = "Both zenity and kdialog are not found in your system's $PATH environment variable.";
        const char *err2 = "Please install either zenity and/or kdialog with your system's package manager";
        const char *err3 = "before attempting to run this application. You may press any key to abort..."; 
        XEvent event;
        while (true) {
          XNextEvent(display, &event);
          if (owner && owner != RootWindow(display, screen)) {
            XWindowAttributes xattr;
            XStoreName(display, owner, "Fatal Error");
            XSetIcon(display, owner, widget_get_icon());
            XGetWindowAttributes(display, owner, &xattr);
            XResizeWindow(display, window, xattr.width, xattr.height);
          }
          if (event.type == Expose) {
            XDrawString(display, window, DefaultGC(display, screen), 32, 32, err1, strlen(err1));
            XDrawString(display, window, DefaultGC(display, screen), 32, 32 * 2, err2, strlen(err2));
            XDrawString(display, window, DefaultGC(display, screen), 32, 32 * 3, err3, strlen(err3));
          }
          if (event.type == KeyPress) {
            break;
          }
        }
        XCloseDisplay(display);
      }
      exit(0);
    }
    #endif
  }
}

// set dialog transient; set title caption.
void modify_shell_dialog(PROCID pid) {
  SetErrorHandlers(); int sz = 0;
  WINDOWID *arr = nullptr; Window wid = 0;
  Display *display = XOpenDisplay(nullptr);
  xprocess::window_id_from_proc_id(pid, &arr, &sz);
  for (int i = 0; i < sz; i++) {
    wid = (Window)strtoull(arr[sz - 1], nullptr, 10);
    XSetIcon(display, wid, widget_get_icon());
    XSetTransientForHint(display, wid, (Window)(std::intptr_t)strtoul(widget_get_owner(), nullptr, 10));
    int len = strlen(widget_get_caption()) + 1; char *buffer = new char[len]();
    strcpy(buffer, widget_get_caption()); XChangeProperty(display, wid,
    XInternAtom(display, "_NET_WM_NAME", false),
    XInternAtom(display, "UTF8_STRING", false),
    8, PropModeReplace, (unsigned char *)buffer, len);
    delete[] buffer; Window focus; int revert; while (!modifyInit) { 
    XSynchronize(display, true); XRaiseWindow(display, wid);
    XSetInputFocus(display, wid, RevertToParent, CurrentTime);
    XFlush(display); XGetInputFocus(display, &focus, &revert);
    if (wid == focus) modifyInit = true; }
  }
  xprocess::free_window_id(arr);
  XCloseDisplay(display);
}

string add_escaping(string str, bool is_caption, string new_caption) {
  string result = str; if (is_caption && str == "") result = new_caption;
  result = string_replace_all(result, "\"", "\\\"");
  return result;
}

string create_shell_dialog(string command) {
  string output; modifyInit = false;
  PROCID pid = xprocess::process_execute_async(command.c_str());
  if (pid) {
    while (!xprocess::completion_status_from_executed_process(pid)) {
      modify_shell_dialog(pid); std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
    output = xprocess::executed_process_read_from_standard_output(pid);
    xprocess::free_executed_process_standard_output(pid);
    xprocess::free_executed_process_standard_input(pid);
    while (!output.empty() && (output.back() == '\r' || output.back() == '\n')) {
      output.pop_back();
    }
  }
  return output;
}

string remove_trailing_zeros(double numb) {
  string strnumb = to_string(numb);

  while (!strnumb.empty() && strnumb.find('.') != string::npos && (strnumb.back() == '.' || strnumb.back() == '0'))
    strnumb.pop_back();

  return strnumb;
}

#if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
vector<vector<string>> nfd_filter(string input) {
  input = string_replace_all(input, "\r", "");
  input = string_replace_all(input, "\n", "");
  vector<string> stringVec = string_split(input, '|');
  vector<vector<string>> output;
  vector<string> vec;
  unsigned ind = 0;
  for (string str : stringVec) {
    if (ind % 2 == 0) {
      size_t first = str.find('(');
      if (first != string::npos) {
        size_t last = str.find(')', first);
        if (last != string::npos)
          str.erase(first, last - first + 1);
      }
      if (!str.empty() && str.back() == ' ') {
        str.pop_back();
      }
      vec.push_back(str);
    } else {
      vec.push_back(string_replace_all(string_replace_all(str, ";", ","), "*.", ""));
      output.push_back(vec);
      vec.clear();
    }
    ind++;
  }
  return output;
}
#endif

string zenity_filter(string input) {
  input = string_replace_all(input, "\r", "");
  input = string_replace_all(input, "\n", "");
  vector<string> stringVec = string_split(input, '|');
  string string_output;
  unsigned ind = 0;
  for (string str : stringVec) {
    if (ind % 2 == 0)
      string_output += string(" --file-filter=\"") +
        add_escaping(string_replace_all(str, "*.*", "*"), false, "") + string("|");
    else {
      std::replace(str.begin(), str.end(), ';', ' ');
      string_output += add_escaping(string_replace_all(str, "*.*", "*"), false, "") + string("\"");
    }
    ind++;
  }
  return string_output;
}

string kdialog_filter(string input) {
  input = string_replace_all(input, "\r", "");
  input = string_replace_all(input, "\n", "");
  vector<string> stringVec = string_split(input, '|');
  string string_output = " \"";
  unsigned ind = 0;
  for (string str : stringVec) {
    if (ind % 2 == 0) {
      if (ind != 0)
        string_output += "\n";
      size_t first = str.find('(');
      if (first != string::npos) {
        size_t last = str.find(')', first);
        if (last != string::npos)
          str.erase(first, last - first + 1);
      }
      string_output += add_escaping(str, false, "") + string(" (");
    } else {
      std::replace(str.begin(), str.end(), ';', ' ');
      string_output += add_escaping(string_replace_all(str, "*.*", "*"), false, "") + string(")");
    }
    ind++;
  }
  string_output += "\"";
  return string_output;
}

int color_get_red(int col) { return ((col & 0x000000FF)); }
int color_get_green(int col) { return ((col & 0x0000FF00) >> 8); }
int color_get_blue(int col) { return ((col & 0x00FF0000) >> 16); }

int make_color_rgb(unsigned char r, unsigned char g, unsigned char b) {
  return r | (g << 8) | (b << 16);
}

int show_message_helperfunc(const char *str) {
  change_relative_to_qt();
  string str_command;
  string str_title = message_cancel ? add_escaping(caption, true, cpt_array[CAPTION_QUESTION]) : add_escaping(caption, true, cpt_array[CAPTION_INFORMATION]);
  string str_iconflag = (dm_dialogengine == dm_zenity) ? " --window-icon=\"" : " --icon \"";
  if (current_icon == "") current_icon = filename_absolute("assets/icon.png");
  string str_icon = file_exists(current_icon) ? str_iconflag + add_escaping(current_icon, false, "") + string("\"") : "";
  string caption_previous = caption;
  caption = (str_title == cpt_array[CAPTION_INFORMATION]) ? cpt_array[CAPTION_INFORMATION] : caption;
  caption = (str_title == cpt_array[CAPTION_QUESTION]) ? cpt_array[CAPTION_QUESTION] : caption;

  string str_cancel;
  string str_echo = "echo 1";

  if (message_cancel)
    str_echo = "if [ $? = 0 ] ;then echo 1;else echo -1;fi";

  if (dm_dialogengine == dm_zenity) {
    string str_icon_2 = string("\" --icon-name=dialog-information") + str_icon + string(");");
    str_cancel = string("--info --ok-label=\"") + add_escaping(btn_array[BUTTON_OK], true, "") + string("\" ");

    if (message_cancel) {
      str_icon_2 = string("\" --icon-name=dialog-question") + str_icon + string(");");
      str_cancel = string("--question --ok-label=\"") + add_escaping(btn_array[BUTTON_OK], true, "") + string("\" --cancel-label=\"") + add_escaping(btn_array[BUTTON_CANCEL], true, "") + string("\" ");
    }

    str_command = string("ans=$(zenity ") +
    str_cancel + string("--title=\"") + str_title + string("\" --no-wrap --text=\"") +
    add_escaping(str, false, "") + str_icon_2 + str_echo;
  }
  else if (dm_dialogengine == dm_kdialog) {
    str_cancel = string("--msgbox \"") + add_escaping(str, false, "") + string("\" --ok-label \"") + add_escaping(btn_array[BUTTON_OK], true, "") + string("\"") + str_icon + string(" ");

    if (message_cancel)
      str_cancel = string("--yesno \"") + add_escaping(str, false, "") + string("\" --yes-label \"") + add_escaping(btn_array[BUTTON_OK], true, "") + string("\" --no-label \"") + add_escaping(btn_array[BUTTON_CANCEL], true, "") + string("\"") + str_icon + string(" ");

    str_command = string("kdialog ") +
    str_cancel + string("--title \"") + str_title + string("\";") + str_echo;
  }

  string str_result = create_shell_dialog(str_command);
  caption = caption_previous;
  double result = strtod(str_result.c_str(), nullptr);
  return (int)result;
}

int show_question_helperfunc(const char *str) {
  change_relative_to_qt();
  string str_command;
  string str_title = add_escaping(caption, true, cpt_array[CAPTION_QUESTION]);
  string str_iconflag = (dm_dialogengine == dm_zenity) ? " --window-icon=\"" : " --icon \"";
  if (current_icon == "") current_icon = filename_absolute("assets/icon.png");
  string str_icon = file_exists(current_icon) ? str_iconflag + add_escaping(current_icon, false, "") + string("\"") : "";
  string caption_previous = caption;
  caption = (str_title == cpt_array[CAPTION_QUESTION]) ? cpt_array[CAPTION_QUESTION] : caption;
  string str_cancel = "";

  if (dm_dialogengine == dm_zenity) {
    if (question_cancel)
      str_cancel = string("--extra-button=\"") + add_escaping(btn_array[BUTTON_CANCEL], true, "") + string("\" ");

    str_command = string("ans=$(zenity ") +
    string("--question --ok-label=\"") + add_escaping(btn_array[BUTTON_YES], true, "") + string("\" --cancel-label=\"") + add_escaping(btn_array[BUTTON_NO], true, "") + string("\" ") + str_cancel +  string("--title=\"") +
    str_title + string("\" --no-wrap --text=\"") + add_escaping(str, false, "") +
    string("\" --icon-name=dialog-question") + str_icon + string(");if [ $? = 0 ] ;then echo 1;elif [ $ans = \"") + btn_array[BUTTON_CANCEL] + string("\" ] ;then echo -1;else echo 0;fi");
  }
  else if (dm_dialogengine == dm_kdialog) {
    if (question_cancel)
      str_cancel = "cancel";

    str_command = string("kdialog ") +
    string("--yesno") + str_cancel + string(" \"") + add_escaping(str, false, "") + string("\" ") +
    string("--yes-label \"") + add_escaping(btn_array[BUTTON_YES], true, "") + string("\" --no-label \"") + add_escaping(btn_array[BUTTON_NO], true, "") + string("\" ") + string("--title \"") + str_title + string("\" ") + str_icon + string(";") +
    string("x=$? ;if [ $x = 0 ] ;then echo 1;elif [ $x = 1 ] ;then echo 0;elif [ $x = 2 ] ;then echo -1;fi");
  }

  string str_result = create_shell_dialog(str_command);
  caption = caption_previous;
  double result = strtod(str_result.c_str(), nullptr);
  return (int)result;
}

} // anonymous namespace

int show_message(const char *str) {
  message_cancel = false;
  return show_message_helperfunc(str);
}

int show_message_cancelable(const char *str) {
  message_cancel = true;
  return show_message_helperfunc(str);
}

int show_question(const char *str) {
  question_cancel = false;
  return show_question_helperfunc(str);
}

int show_question_cancelable(const char *str) {
  question_cancel = true;
  return show_question_helperfunc(str);
}

int show_attempt(const char *str) {
  change_relative_to_qt();
  string str_command;
  string str_title = add_escaping(caption, true, cpt_array[CAPTION_ERROR]);
  string str_iconflag = (dm_dialogengine == dm_zenity) ? " --window-icon=\"" : " --icon \"";
  if (current_icon == "") current_icon = filename_absolute("assets/icon.png");
  string str_icon = file_exists(current_icon) ? str_iconflag + add_escaping(current_icon, false, "") + string("\"") : "";
  string caption_previous = caption;
  caption = (str_title == cpt_array[CAPTION_ERROR]) ? cpt_array[CAPTION_ERROR] : caption;

  if (dm_dialogengine == dm_zenity) {
    str_command = string("ans=$(zenity ") +
    string("--question --ok-label=\"") + add_escaping(btn_array[BUTTON_RETRY], true, "") + string("\" --cancel-label=\"") + add_escaping(btn_array[BUTTON_CANCEL], true, "") + string("\" ") +  string("--title=\"") +
    str_title + string("\" --no-wrap --text=\"") + add_escaping(str, false, "") +
    string("\" --icon-name=dialog-error ") + str_icon + string(");if [ $? = 0 ] ;then echo 0;else echo -1;fi");
  }
  else if (dm_dialogengine == dm_kdialog) {
    str_command = string("kdialog ") +
    string("--warningyesno") + string(" \"") + add_escaping(str, false, "") + string("\" ") +
    string("--yes-label \"") + add_escaping(btn_array[BUTTON_RETRY], true, "") + string("\" --no-label \"") + add_escaping(btn_array[BUTTON_CANCEL], true, "") + string("\" ") + string("--title \"") +
    str_title + string("\" ") + str_icon + string(";") + string("x=$? ;if [ $x = 0 ] ;then echo 0;else echo -1;fi");
  }

  string str_result = create_shell_dialog(str_command);
  caption = caption_previous;
  double result = strtod(str_result.c_str(), nullptr);
  return (int)result;
}

int show_error(const char *str, bool abort) {
  change_relative_to_qt();
  string str_command;
  string str_title = add_escaping(caption, true, cpt_array[CAPTION_ERROR]);
  string str_iconflag = (dm_dialogengine == dm_zenity) ? " --window-icon=\"" : " --icon \"";
  if (current_icon == "") current_icon = filename_absolute("assets/icon.png");
  string str_icon = file_exists(current_icon) ? str_iconflag + add_escaping(current_icon, false, "") + string("\"") : "";
  string caption_previous = caption;
  caption = (str_title == cpt_array[CAPTION_ERROR]) ? cpt_array[CAPTION_ERROR] : caption;
  string str_echo;

  if (dm_dialogengine == dm_zenity) {
    str_echo = abort ? "echo 1" : "if [ $? = 0 ] ;then echo 1;else echo -1;fi";

    if (abort) {
      str_command = string("ans=$(zenity ") +
      string("--info --ok-label=\"") + add_escaping(btn_array[BUTTON_ABORT], true, "") + string("\" ") +
      string("--title=\"") + str_title + string("\" --no-wrap --text=\"") +
      add_escaping(str, false, "") + string("\" --icon-name=dialog-error ") + str_icon + string(");") + str_echo;
    } else {
      str_command = string("ans=$(zenity ") +
      string("--question --ok-label=\"") + add_escaping(btn_array[BUTTON_ABORT], true, "") + string("\" --cancel-label=\"") + add_escaping(btn_array[BUTTON_IGNORE], true, "") + string("\" ") +
      string("--title=\"") + str_title + string("\" --no-wrap --text=\"") +
      add_escaping(str, false, "") + string("\" --icon-name=dialog-error ") + str_icon + string(");") + str_echo;
    }
  }
  else if (dm_dialogengine == dm_kdialog) {
    str_echo = abort ? "echo 1" : "x=$? ;if [ $x = 0 ] ;then echo 1;elif [ $x = 1 ] ;then echo -1;fi";

    if (abort) {
      str_command = string("kdialog ") +
      string("--sorry \"") + add_escaping(str, false, "") + string("\" ") +
      string("--ok-label \"") + add_escaping(btn_array[BUTTON_ABORT], true, "") + string("\" ") +
      string("--title \"") + str_title + string("\" ") + str_icon + string(";") + str_echo;
    } else {
      str_command = string("kdialog ") +
      string("--warningyesno \"") + add_escaping(str, false, "") + string("\" ") +
      string("--yes-label \"") + add_escaping(btn_array[BUTTON_ABORT], true, "") + string("\" --no-label \"") + add_escaping(btn_array[BUTTON_IGNORE], true, "") + string("\" ") +
      string("--title \"") + str_title + string("\" ") + str_icon + string(";") + str_echo;
    }
  }

  string str_result = create_shell_dialog(str_command);
  caption = caption_previous;
  double result = strtod(str_result.c_str(), nullptr);
  if (result == 1) exit(0);
  return (int)result;
}

const char *get_string(const char *str, const char *def) {
  change_relative_to_qt();
  string str_command;
  string str_title = add_escaping(caption, true, cpt_array[CAPTION_INPUT]);
  string caption_previous = caption;
  caption = (str_title == cpt_array[CAPTION_INPUT]) ? cpt_array[CAPTION_INPUT] : caption;
  string str_iconflag = (dm_dialogengine == dm_zenity) ? " --window-icon=\"" : " --icon \"";
  if (current_icon == "") current_icon = filename_absolute("assets/icon.png");
  string str_icon = file_exists(current_icon) ? str_iconflag + add_escaping(current_icon, false, "") + string("\"") : "";

  if (dm_dialogengine == dm_zenity) {
    str_command = string("ans=$(zenity ") +
    string("--entry --title=\"") + str_title + string("\"") + str_icon + string(" --text=\"") +
    add_escaping(str, false, "") + string("\" --entry-text=\"") +
    add_escaping(def, false, "") + string("\");echo $ans");
  }
  else if (dm_dialogengine == dm_kdialog) {
    str_command = string("ans=$(kdialog ") +
    string("--inputbox \"") + add_escaping(str, false, "") + string("\" \"") +
    add_escaping(def, false, "") + string("\" --title \"") +
    str_title + string("\"") + str_icon + string(");echo $ans");
  }

  static string result;
  result = create_shell_dialog(str_command);
  if (result.empty()) cancel_pressed = true;
  caption = caption_previous;
  return result.c_str();
}

const char *get_password(const char *str, const char *def) {
  change_relative_to_qt();
  string str_command;
  string str_title = add_escaping(caption, true, cpt_array[CAPTION_INPUT]);
  string str_iconflag = (dm_dialogengine == dm_zenity) ? " --window-icon=\"" : " --icon \"";
  if (current_icon == "") current_icon = filename_absolute("assets/icon.png");
  string str_icon = file_exists(current_icon) ? str_iconflag + add_escaping(current_icon, false, "") + string("\"") : "";
  string caption_previous = caption;
  caption = (str_title == cpt_array[CAPTION_INPUT]) ? cpt_array[CAPTION_INPUT] : caption;

  if (dm_dialogengine == dm_zenity) {
    str_command = string("ans=$(zenity ") +
    string("--entry --title=\"") + str_title + string("\"") + str_icon + string(" --text=\"") +
    add_escaping(str, false, "") + string("\" --hide-text --entry-text=\"") +
    add_escaping(def, false, "") + string("\");echo $ans");
  }
  else if (dm_dialogengine == dm_kdialog) {
    str_command = string("ans=$(kdialog ") +
    string("--password \"") + add_escaping(str, false, "") + string("\" \"") +
    add_escaping(def, false, "") + string("\" --title \"") +
    str_title + string("\"") + str_icon + string(");echo $ans");
  }

  static string result;
  result = create_shell_dialog(str_command);
  if (result.empty()) cancel_pressed = true;
  caption = caption_previous;
  return result.c_str();
}

double get_integer(const char *str, double def) {
  double DIGITS_MIN = -999999999999999;
  double DIGITS_MAX = 999999999999999;

  if (def < DIGITS_MIN) def = DIGITS_MIN;
  if (def > DIGITS_MAX) def = DIGITS_MAX;

  string str_def = remove_trailing_zeros(def);
  string str_result = get_string(str, str_def.c_str());    
  
  for (int i = 0; !str_result.empty() && i < str_result.length() && (!std::isdigit(str_result[i]) && str_result[i] != '-' && str_result[i] != '+' && str_result[i] != '.'); i++) {
    str_result = str_result.substr(i + 1);  
  }
  
  if (str_result.empty()) cancel_pressed = true; else cancel_pressed = false;
  double result = strtod(str_result.c_str(), nullptr);

  if (result < DIGITS_MIN) result = DIGITS_MIN;
  if (result > DIGITS_MAX) result = DIGITS_MAX;
  return result;
}

double get_passcode(const char *str, double def) {
  double DIGITS_MIN = -999999999999999;
  double DIGITS_MAX = 999999999999999;

  if (def < DIGITS_MIN) def = DIGITS_MIN;
  if (def > DIGITS_MAX) def = DIGITS_MAX;

  string str_def = remove_trailing_zeros(def);
  string str_result = get_password(str, str_def.c_str());    
  
  for (int i = 0; !str_result.empty() && i < str_result.length() && (!std::isdigit(str_result[i]) && str_result[i] != '-' && str_result[i] != '+' && str_result[i] != '.'); i++) {
    str_result = str_result.substr(i + 1);  
  }
  
  if (str_result.empty()) cancel_pressed = true; else cancel_pressed = false;
  double result = strtod(str_result.c_str(), nullptr);

  if (result < DIGITS_MIN) result = DIGITS_MIN;
  if (result > DIGITS_MAX) result = DIGITS_MAX;
  return result;
}

const char *get_open_filename(const char *filter, const char *fname) {
  return get_open_filename_ext(filter, fname, "", cpt_array[CAPTION_OPEN].c_str());
}

const char *get_open_filename_ext(const char *filter, const char *fname, const char *dir, const char *title) {
  #if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
  static string res;
  cancel_pressed = false;
  nfdresult_t nfdresult = NFD_Init();
  if (nfdresult != NFD_ERROR) {
    nfdu8char_t *outPath;
    setenv("QT_QPA_PLATFORM", "xcb", 1);
    setenv("GDK_BACKEND", "x11", 1);
    vector<vector<string>> vec;
    vec = nfd_filter(filter);
    vector<nfdu8filteritem_t> filters;
    filters.reserve(vec.size());
    for (const auto &ext : vec) {
      if (!ext.empty() && ext.size() == 2 && ext[1].find("*") == string::npos) {
        filters.emplace_back(nfdu8filteritem_t{ ext[0].c_str(), ext[1].c_str() });
      }
    }
    nfdopendialogu8args_t args = { 0 };
    args.filterList = filters.data();
    args.filterCount = filters.size();
    args.defaultPath = ((dir && strlen(dir)) ? dir : (getenv("HOME") ? getenv("HOME") : "/"));
    args.parentWindow.type = NFD_WINDOW_HANDLE_TYPE_X11;
    args.parentWindow.handle = (void *)(unsigned long long)strtoul(widget_get_owner(), nullptr, 10);
    args.title = ((title && strlen(title)) ? title : cpt_array[CAPTION_OPEN].c_str());
    args.acceptLabel = widget_get_button_name(BUTTON_OK);
    args.cancelLabel = widget_get_button_name(BUTTON_CANCEL);
    nfdresult = NFD_OpenDialogU8_With(&outPath, &args);
    if (nfdresult == NFD_OKAY) {
      res = outPath;
      NFD_FreePathU8(outPath);
    } else {
      res.clear();
    }
    NFD_Quit();
  }
  if (nfdresult != NFD_ERROR) {
    return res.c_str();
  } else {
  #endif
    change_relative_to_qt();
    string str_command; string pwd;
    string caption_previous = caption;
    if (dm_dialogengine == dm_zenity) {
      string str_title = add_escaping(title, true, cpt_array[CAPTION_OPEN]);
      caption = (str_title == cpt_array[CAPTION_OPEN]) ? cpt_array[CAPTION_OPEN] : title;
      string str_fname = filename_name(fname);
      string str_dir = dir;
      string str_path; if (!str_dir.empty()) str_path = str_dir + string("/") + str_fname;
      else str_path = string("$HOME/") + str_fname;
      str_command = string("ans=$(zenity ") +
      string("--file-selection --title=\"") + str_title + string("\" --filename=\"") +
      add_escaping(str_path, false, "") + string("\"") + zenity_filter(filter) + string(");echo $ans");
    } else if (dm_dialogengine == dm_kdialog) {
      string str_title = add_escaping(title, true, cpt_array[CAPTION_OPEN]);
      caption = (str_title == cpt_array[CAPTION_OPEN]) ? cpt_array[CAPTION_OPEN] : title;
      string str_fname = filename_name(fname);
      string str_dir = dir;
      string str_path; if (!str_dir.empty()) str_path = str_dir + string("/") + str_fname;
      if (str_dir.empty()) pwd = string("\"$HOME/") + add_escaping(str_fname, false, "") + string("\"");
      else pwd = string("\"") + add_escaping(str_path, false, "") + string("\"");
      str_command = string("ans=$(kdialog ") +
      string("--getopenfilename ") + pwd + kdialog_filter(filter) +
      string(" --title \"") + str_title + string("\"") + string(");echo $ans");
    }
    static string result;
    result = create_shell_dialog(str_command);
    caption = caption_previous;
    if (file_exists(result))
      return result.c_str();
    return "";
  #if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
  }
  #endif
}

const char *get_open_filenames(const char *filter, const char *fname) {
  return get_open_filenames_ext(filter, fname, "", cpt_array[CAPTION_OPEN].c_str());
}

const char *get_open_filenames_ext(const char *filter, const char *fname, const char *dir, const char *title) {
  #if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
  string res;
  static string final_res;
  cancel_pressed = false;
  nfdresult_t nfdresult = NFD_Init();
  if (nfdresult != NFD_ERROR) {
    const nfdpathset_t *outPaths;
    setenv("QT_QPA_PLATFORM", "xcb", 1);
    setenv("GDK_BACKEND", "x11", 1);
    vector<vector<string>> vec;
    vec = nfd_filter(filter);
    vector<nfdu8filteritem_t> filters;
    filters.reserve(vec.size());
    for (const auto &ext : vec) {
      if (!ext.empty() && ext.size() == 2 && ext[1].find("*") == string::npos) {
        filters.emplace_back(nfdu8filteritem_t{ ext[0].c_str(), ext[1].c_str() });
      }
    }
    nfdopendialogu8args_t args = { 0 };
    args.filterList = filters.data();
    args.filterCount = filters.size();
    args.defaultPath = ((dir && strlen(dir)) ? dir : ((getenv("HOME")) ? getenv("HOME") : "/"));
    args.parentWindow.type = NFD_WINDOW_HANDLE_TYPE_X11;
    args.parentWindow.handle = (void *)(unsigned long long)strtoul(widget_get_owner(), nullptr, 10);
    args.title = ((title && strlen(title)) ? title : cpt_array[CAPTION_OPEN].c_str());
    args.acceptLabel = widget_get_button_name(BUTTON_OK);
    args.cancelLabel = widget_get_button_name(BUTTON_CANCEL);
    nfdresult = NFD_OpenDialogMultipleU8_With(&outPaths, &args);
    if (nfdresult == NFD_OKAY) {
      nfdpathsetsize_t numPaths;
      NFD_PathSet_GetCount(outPaths, &numPaths);
      for (nfdpathsetsize_t i = 0; i < numPaths; i++) {
        nfdu8char_t *path;
        NFD_PathSet_GetPath(outPaths, i, &path);
        res += path;
        if (i < numPaths - 1) {
          res += string("\n");
        }
        NFD_PathSet_FreePath(path);
      }
      NFD_PathSet_Free(outPaths);
      final_res = res;
    } else {
      final_res.clear();
    }
    NFD_Quit();
  }
  if (nfdresult != NFD_ERROR) {
    return final_res.c_str();
  } else {
  #endif
    change_relative_to_qt();
    string str_command; string pwd;
    string caption_previous = caption;
    if (dm_dialogengine == dm_zenity) {
      string str_title = add_escaping(title, true, cpt_array[CAPTION_OPEN]);
      caption = (str_title == cpt_array[CAPTION_OPEN]) ? cpt_array[CAPTION_OPEN] : title;
      string str_fname = filename_name(fname);
      string str_dir = dir;
      string str_path; if (!str_dir.empty()) str_path = str_dir + string("/") + str_fname;
      else str_path = string("$HOME/") + str_fname;
      str_command = string("zenity ") +
      string("--file-selection --multiple --separator='\n' --title=\"") + str_title + string("\" --filename=\"") +
      add_escaping(str_path, false, "") + string("\"") + zenity_filter(filter);
    } else if (dm_dialogengine == dm_kdialog) {
      string str_title = add_escaping(title, true, cpt_array[CAPTION_OPEN]);
      caption = (str_title == cpt_array[CAPTION_OPEN]) ? cpt_array[CAPTION_OPEN] : title;
      string str_fname = filename_name(fname);
      string str_dir = dir;
      string str_path; if (!str_dir.empty()) str_path = str_dir + string("/") + str_fname;
      if (str_dir.empty()) pwd = string("\"$HOME/") + add_escaping(str_fname, false, "") + string("\"");
      else pwd = string("\"") + add_escaping(str_path, false, "") + string("\"");
      str_command = string("kdialog ") +
      string("--getopenfilename ") + pwd + kdialog_filter(filter) +
      string(" --multiple --separate-output --title \"") + str_title + string("\"");
    }
    static string result;
    result = create_shell_dialog(str_command);
    caption = caption_previous;
    vector<string> stringVec = string_split(result, '\n');
    bool success = true;
    for (const string &str : stringVec) {
      if (!file_exists(str))
        success = false;
    }
    if (success)
      return result.c_str();
    return "";
  #if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
  }
  #endif
}

const char *get_save_filename(const char *filter, const char *fname) {
  return get_save_filename_ext(filter, fname, "", cpt_array[CAPTION_SAVE].c_str());
}

const char *get_save_filename_ext(const char *filter, const char *fname, const char *dir, const char *title) {
  #if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
  static string res;
  cancel_pressed = false;
  nfdresult_t nfdresult = NFD_Init();
  if (nfdresult != NFD_ERROR) {
    nfdu8char_t *outPath;
    setenv("QT_QPA_PLATFORM", "xcb", 1);
    setenv("GDK_BACKEND", "x11", 1);
    vector<vector<string>> vec;
    vec = nfd_filter(filter);
    vector<nfdu8filteritem_t> filters;
    filters.reserve(vec.size());
    for (const auto &ext : vec) {
      if (!ext.empty() && ext.size() == 2 && ext[1].find("*") == string::npos) {
        filters.emplace_back(nfdu8filteritem_t{ ext[0].c_str(), ext[1].c_str() });
      }
    }
    nfdsavedialogu8args_t args = { 0 };
    args.filterList = filters.data();
    args.filterCount = filters.size();
    args.defaultPath = ((dir && strlen(dir)) ? dir : (getenv("HOME") ? getenv("HOME") : "/"));
    args.defaultName = ((fname && strlen(fname)) ? fname : nullptr);
    args.parentWindow.type = NFD_WINDOW_HANDLE_TYPE_X11;
    args.parentWindow.handle = (void *)(unsigned long long)strtoul(widget_get_owner(), nullptr, 10);
    args.title = ((title && strlen(title)) ? title : cpt_array[CAPTION_SAVE].c_str());
    args.acceptLabel = widget_get_button_name(BUTTON_OK);
    args.cancelLabel = widget_get_button_name(BUTTON_CANCEL);
    nfdresult = NFD_SaveDialogU8_With(&outPath, &args);
    if (nfdresult == NFD_OKAY) {
      res = outPath;
      NFD_FreePathU8(outPath);
    } else {
      res.clear();
    }
    NFD_Quit();
  }
  if (nfdresult != NFD_ERROR) {
    return res.c_str();
  } else {
  #endif
    change_relative_to_qt();
    string str_command; string pwd;
    string caption_previous = caption;
    if (dm_dialogengine == dm_zenity) {
      string str_title = add_escaping(title, true, cpt_array[CAPTION_SAVE]);
      caption = (str_title == cpt_array[CAPTION_SAVE]) ? cpt_array[CAPTION_SAVE] : title;
      string str_fname = filename_name(fname);
      string str_dir = dir;
      string str_path; if (!str_dir.empty()) str_path = str_dir + string("/") + str_fname;
      else str_path = string("$HOME/") + str_fname;
      str_command = string("ans=$(zenity ") +
      string("--file-selection  --save --confirm-overwrite --title=\"") + str_title + string("\" --filename=\"") +
      add_escaping(str_path, false, "") + string("\"") + zenity_filter(filter) + string(");echo $ans");
    } else if (dm_dialogengine == dm_kdialog) {
      string str_title = add_escaping(title, true, cpt_array[CAPTION_SAVE]);
      caption = (str_title == cpt_array[CAPTION_SAVE]) ? cpt_array[CAPTION_SAVE] : title;
      string str_fname = filename_name(fname);
      string str_dir = dir;
      string str_path; if (!str_dir.empty()) str_path = str_dir + string("/") + str_fname;
      if (str_dir.empty()) pwd = string("\"$HOME/") + add_escaping(str_fname, false, "") + string("\"");
      else pwd = string("\"") + add_escaping(str_path, false, "") + string("\"");
      str_command = string("ans=$(kdialog ") +
      string("--getsavefilename ") + pwd + kdialog_filter(filter) +
      string(" --title \"") + str_title + string("\"") + string(");echo $ans");
    }
    static string result;
    result = create_shell_dialog(str_command);
    caption = caption_previous;
    return result.c_str();
  #if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
  }
  #endif
}

const char *get_directory(const char *dname) {
  return get_directory_alt(cpt_array[CAPTION_DIRECTORY].c_str(), dname);
}

const char *get_directory_alt(const char *capt, const char *root) {
  #if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
  static string res;
  static string final_res;
  cancel_pressed = false;
  nfdresult_t nfdresult = NFD_Init();
  if (nfdresult != NFD_ERROR) {
    nfdu8char_t *outPath;
    setenv("QT_QPA_PLATFORM", "xcb", 1);
    setenv("GDK_BACKEND", "x11", 1);
    nfdpickfolderu8args_t args = { 0 };
    args.defaultPath = ((root && strlen(root)) ? root : (getenv("HOME") ? getenv("HOME") : "/"));
    args.parentWindow.type = NFD_WINDOW_HANDLE_TYPE_X11;
    args.parentWindow.handle = (void *)(unsigned long long)strtoul(widget_get_owner(), nullptr, 10);
    args.title = ((capt && strlen(capt)) ? capt : cpt_array[CAPTION_DIRECTORY].c_str());
    args.acceptLabel = widget_get_button_name(BUTTON_OK);
    args.cancelLabel = widget_get_button_name(BUTTON_CANCEL);
    nfdresult = NFD_PickFolderU8_With(&outPath, &args);
    if (nfdresult == NFD_OKAY) {
      res = outPath;
      NFD_FreePathU8(outPath);
    } else {
      res.clear();
    }
    NFD_Quit();
  }
  if (nfdresult != NFD_ERROR && (res.empty() || res == "/")) {
    return res.c_str();
  }
  final_res = ((!res.empty() && res.back() != '/') ? res + string("/") : res);
  if (nfdresult != NFD_ERROR) {
    return final_res.c_str();
  } else {
  #endif
    change_relative_to_qt();
    string str_command; string pwd;
    string caption_previous = caption;
    if (dm_dialogengine == dm_zenity) {
      string str_title = add_escaping(capt, true, cpt_array[CAPTION_DIRECTORY]);
      caption = (str_title == cpt_array[CAPTION_DIRECTORY]) ? cpt_array[CAPTION_DIRECTORY] : capt;
      string str_dname = root;
      if (str_dname.empty() || str_dname[0] != '/') str_dname = "$HOME";
      string str_end = ");if [ $ans = / ] ;then echo $ans;elif [ $? = 1 ] ;then echo $ans/;else echo $ans;fi";
      str_command = string("ans=$(zenity ") +
      string("--file-selection --directory --title=\"") + str_title + string("\" --filename=\"") +
      add_escaping(str_dname, false, "") + string("\"") + str_end;
    } else if (dm_dialogengine == dm_kdialog) {
      string str_title = add_escaping(capt, true, cpt_array[CAPTION_DIRECTORY]);
      caption = (str_title == cpt_array[CAPTION_DIRECTORY]) ? cpt_array[CAPTION_DIRECTORY] : capt;
      string str_dname = root;
      if (str_dname.empty() || str_dname[0] != '/') pwd = "\"$HOME/\"";
      else pwd = string("\"") + add_escaping(str_dname, false, "") + string("\"");
      str_command = string("ans=$(kdialog ") +
      string("--getexistingdirectory ") + pwd + string(" --title \"") + str_title + string("\");echo $ans");
    }
    static string result;
    result = create_shell_dialog(str_command);
    caption = caption_previous;
    if (result.empty() || result == "/") {
      return result.c_str();
    }
    static string final_result;
    final_result = ((result.back() != '/') ? result + string("/") : result);
    return final_result.c_str();
  #if (USE_XDG_DESKTOP_PORTAL && (defined(__linux__) && !defined(__ANDROID__)))
  }
  #endif
}

int get_color(int defcol) {
  return get_color_ext(defcol, cpt_array[CAPTION_COLOR].c_str());
}

int get_color_ext(int defcol, const char *title) {
  change_relative_to_qt();
  string str_command;
  string str_title = add_escaping(title, true, cpt_array[CAPTION_COLOR]);
  string caption_previous = caption;
  caption = (str_title == cpt_array[CAPTION_COLOR]) ? cpt_array[CAPTION_COLOR] : title;
  string str_defcol;
  string str_result;
  string str_iconflag = (dm_dialogengine == dm_zenity) ? " --window-icon=\"" : " --icon \"";
  if (current_icon == "") current_icon = filename_absolute("assets/icon.png");
  string str_icon = file_exists(current_icon) ? str_iconflag + add_escaping(current_icon, false, "") + string("\"") : "";

  int red; int green; int blue;
  red = color_get_red(defcol);
  green = color_get_green(defcol);
  blue = color_get_blue(defcol);

  if (dm_dialogengine == dm_zenity) {
    str_defcol = string("rgb(") + to_string(red) + string(",") +
    to_string(green) + string(",") + to_string(blue) + string(")");
    str_command = string("ans=$(zenity ") +
    string("--color-selection --show-palette --title=\"") + str_title + string("\" --color='") +
    str_defcol + string("'") + str_icon + string(");if [ $? = 0 ] ;then echo $ans;else echo -1;fi");

    str_result = create_shell_dialog(str_command);
    caption = caption_previous;
    if (str_result == "-1") return strtod(str_result.c_str(), nullptr);
    str_result = string_replace_all(str_result, "rgba(", "");
    str_result = string_replace_all(str_result, "rgb(", "");
    str_result = string_replace_all(str_result, ")", "");
    vector<string> stringVec = string_split(str_result, ',');

    unsigned int ind = 0;
    for (const string &str : stringVec) {
      if (ind == 0) red = strtod(str.c_str(), nullptr);
      if (ind == 1) green = strtod(str.c_str(), nullptr);
      if (ind == 2) blue = strtod(str.c_str(), nullptr);
      ind += 1;
    }

  } else if (dm_dialogengine == dm_kdialog) {
    char hexcol[16];
    snprintf(hexcol, sizeof(hexcol), "%02x%02x%02x", red, green, blue);

    str_defcol = string("#") + string(hexcol);
    std::transform(str_defcol.begin(), str_defcol.end(), str_defcol.begin(), ::toupper);

    str_command = string("ans=$(kdialog ") +
    string("--getcolor --default '") + str_defcol + string("' --title \"") + str_title +
    string("\"") + str_icon + string(");if [ $? = 0 ] ;then echo $ans;else echo -1;fi");

    str_result = create_shell_dialog(str_command);
    caption = caption_previous;
    if (str_result == "-1") return strtod(str_result.c_str(), nullptr);
    str_result = str_result.substr(1, str_result.length() - 1);

    unsigned int color;
    stringstream ss2;
    ss2 << std::hex << str_result;
    ss2 >> color;

    blue = color_get_red(color);
    green = color_get_green(color);
    red = color_get_blue(color);
  }

  return (int)make_color_rgb(red, green, blue);
}

const char *widget_get_caption() {
  return caption.c_str();
}

void widget_set_caption(const char *title) {
  caption = title ? title : "";
}

const char *widget_get_owner() {
  static string result;
  result = to_string((unsigned long long)owner);
  return result.c_str();
}

void widget_set_owner(const char *hwnd) {
  string str_hwnd = hwnd;
  owner = (void *)strtoll(str_hwnd.c_str(), nullptr, 10);
}

const char *widget_get_icon() {
  if (current_icon == "")
    current_icon = filename_absolute("assets/icon.png");
  return current_icon.c_str();
}

void widget_set_icon(const char *icon) {
  current_icon = filename_absolute(icon);
}

const char *widget_get_system() {
  if (dm_dialogengine == dm_zenity)
    return "Zenity";

  if (dm_dialogengine == dm_kdialog)
    return "KDialog";

  return "X11";
}

void widget_set_system(const char *sys) {
  string str_sys = sys;

  if (str_sys == "X11")
    dm_dialogengine = dm_x11;

  if (str_sys == "Zenity")
    dm_dialogengine = dm_zenity;

  if (str_sys == "KDialog")
    dm_dialogengine = dm_kdialog;
}

void widget_set_button_name(int type, const char *name) {
  string str_name = name;
  btn_array[type] = str_name;
}

const char *widget_get_button_name(int type) {
  return btn_array[type].c_str();
}

bool widget_get_canceled() {
  return cancel_pressed;
}

void widget_set_locale() {
  widget_set_locale_helper();
}

} // namepace dialog_module
